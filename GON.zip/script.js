
let cuota12 = 0.15


function calcularInteres(valorDelTv) {
    return valorDelTv * cuota12
}

let valorDelTv = parseFloat(prompt("Ingrese el valor de la TV"))
let interes = calcularInteres(valorDelTv)
console.log(interes)

function suma(valorTv, total) {
    console.log(valorTv + total)
}

let total = parseFloat(prompt("ingrese el valor del interes"))
let valorTv = parseFloat(prompt("vuelva a ingresar el valor de la Tv"))

suma(valorTv, total)

let resultado = parseFloat(prompt("Ingrese el total a pagar con el interes incluido"))
if(resultado <= 80000) {
    console.log("Esto es muy barato, lo compro")
} else {
    console.log("Esto es muy caro, no lo compro")
}
